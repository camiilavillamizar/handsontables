import { Component, DoCheck, Input, OnInit, ViewChild } from '@angular/core';
import { HotTableRegisterer } from '@handsontable/angular';
import Handsontable from 'handsontable';
import { HyperFormula } from 'hyperformula';
import { Data } from 'src/app/data/data';
import { commentList, data } from 'src/app/models/handsontable.model';
import { PrincipalService } from '../../services/principal.service';

@Component({
  selector: 'app-tables',
  templateUrl: './tables.component.html',
  styleUrls: ['./tables.component.css']
})
export class TablesComponent implements OnInit {

  constructor(private principalService: PrincipalService){

  }

  contador = 0; 
  @Input() id: number; 

  inicialWidths: number[] =[]
  limitOfHeaders: number = 23; 

  loading: boolean = false; 
  roles: string[] = ["ROLE_ADMIN"]; 

  hotRegisterer = new HotTableRegisterer();
  rOnly: boolean = true; 

  //Table1
  @ViewChild('T1') t1 : HTMLDivElement; 
  columnsToMap: string[] = [];  
  tableData: Data[] = []; 
  columnNames: string[] = []; 
  tableId1 = "table1"; 


  //Table 3
  @ViewChild('T3') t3 : HTMLDivElement; 
  columnsToMap3: string[] = [];  
  tableData3: data[]; 
  columnNames3: string[] = []; 
  tableId3 = "table3"; 


  //Table 2
  @ViewChild('T2') t2 : HTMLDivElement; 
  columnsToMap2: string[] = [];  
  tableData2: data[]; 
  columnNames2: string[] = []; 
  tableId2 = "table2"; 

   // TABLA 4
   @ViewChild('T4') t4: HTMLDivElement;
   columnNames4: string[] = [];
   columnsToMap4: string[] = [];
   tablaData4: Data[] = [];

  // TABLA 5
  @ViewChild('T5') t5: HTMLDivElement;
  columnNames5: string[] = [];
  columnsToMap5: string[] = [];
  tablaData5: Data[] = [];

  // TABLA 5
  @ViewChild('T6') t6: HTMLDivElement;
  columnNames6: string[] = [];
  columnsToMap6: string[] = [];
  tablaData6: Data[] = [];


  public commentsList: commentList ={
    tabla1 : [],
    tabla2 : []
  };
  
  ngOnChanges(): void {
    this.selectProject(); 
  }
  ngOnInit(){
    setInterval(() => {
      this.contador++; 
    }, 1000)

    console.log("componente generado")
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    console.log("COMPONENTE DESTRUIDO")
  }
  selectProject(){
    this.loading = true; 
    let response; 
    let anterior; 
    let detail = (new Data).details; 

    if(this.id == 1){
      response = (new Data).project1; 
      anterior = (new Data).project1Anterior; 
    } else if( this.id == 2){
      response = (new Data).project2;
      anterior = (new Data).project2Anterior; 
    }

    /**
     * PARA PROBAR CON BACKEND
     */
    // if(this.id == 1){
    //   this.principalService.getHandsontableData(693).subscribe(response => {
    //   this.loading = false; 
    //     //Table 1
    //   this.columnsToMap = this.generateColumns(response.columns);     
    //   this.tableData = this.extractDataFromResponse(response.data, "t1"); 
    //   this.columnNames = response.colHeaders;
    //   })

    //   this.principalService.getHandsontableData(222).subscribe(response => {
    //     //Table 1
    //   this.columnsToMap2 = this.generateColumns(response.columns);     
    //   this.tableData2 = this.extractDataFromResponse(response.data, "t1"); 
    //   this.columnNames2 = response.colHeaders;
    //   })
    //   console.log("se va a ejecutar")
    //   this.principalService.getDetailHandsontable([637, 642, 655, 661, 679, 680, 681, 682, 683, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706], "EUR").subscribe(response => {

    //   console.log("yaa")
    //   console.log(response)
    //   this.columnsToMap6 = response.columns;     
    //   this.tablaData6 = response.genericData; 
    //   this.columnNames6 = response.colHeaders;
    //   })
    //   //Table 3
    //   setTimeout(() => {
    //     this.getHandsontable3()
    //     this.getHandsontableIndicators1(); 
    //     this.getHandsontableIndicators2(); 
    //   }, 10000)
    // }else {
    //   this.principalService.getHandsontableData(693).subscribe(response => {
    //   this.loading = false; 
    //     //Table 1
    //   this.columnsToMap = this.generateColumns(response.columns);     
    //   this.tableData = this.extractDataFromResponse(response.data, "t1"); 
    //   this.columnNames = response.colHeaders;
    //   })

    //   this.principalService.getHandsontableData(222).subscribe(response => {
    //     //Table 1
    //   this.columnsToMap2 = this.generateColumns(response.columns);     
    //   this.tableData2 = this.extractDataFromResponse(response.data, "t1"); 
    //   this.columnNames2 = response.colHeaders;
    //   })

    //   console.log("se va a ejecutar")
    //   this.principalService.getDetailHandsontable([637, 642, 655, 661, 679, 680, 681, 682, 683, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706], "EUR").subscribe(response => {

    //   console.log("yaa")
    //   console.log(response)
    //   this.columnsToMap6 = response.columns;     
    //   this.tablaData6 = response.genericData; 
    //   this.columnNames6 = response.colHeaders;
    //   })
    //   //Table 3
    //   setTimeout(() => {
    //     this.getHandsontable3()
    //     this.getHandsontableIndicators1(); 
    //     this.getHandsontableIndicators2(); 
    //   }, 3000)
    // }

    /**
     * PARA PROBAR CON DATOS FIJOS
     */
    setTimeout(() => {

      //Table 1
      this.columnsToMap = this.generateColumns(response.columns);     
      this.tableData = this.extractDataFromResponse(response.data, "t1"); 
      this.columnNames = response.colHeaders;

      //Table 2
      this.columnsToMap2 = this.generateColumns(anterior.columns);     
      this.tableData2 = this.extractDataFromResponse(anterior.data, "t1"); 
      this.columnNames2 = anterior.colHeaders;

      //Table 6
      this.columnsToMap6 = detail.columns;     
      this.tablaData6 = detail.genericData; 
      this.columnNames6 = detail.colHeaders;

      console.log(detail)

      //Table 3, 4 y 5
      setTimeout(() => {
        this.getHandsontable3()
        this.getHandsontableIndicators1(); 
        this.getHandsontableIndicators2(); 
      })

      this.loading = false; 
    }, 1000)
  }

  readOnly(title: string, tableId: string) {
    if (tableId == "tabla2") {
      return true;
    }

    /**
     * Para la fila facturación del mes real 
     */
     let colMesFoto = this.columnNames.findIndex(mes => mes.includes("202109"));
    if(!this.rOnly){this.hotRegisterer.getInstance(this.tableId1).setCellMeta(5, colMesFoto, 'readOnly', false); } 
    else {
        try{
          this.hotRegisterer.getInstance(this.tableId1).setCellMeta(5, colMesFoto, 'readOnly', true); 
        } catch(e){}
    }

    if (title.search("Presupuesto") != -1 || title.search("Ejecutado") != -1 ||
        title.search("Real") != -1 || title.search("Control") != -1 || this.rOnly || 
        title.search("cierre") != -1 || title.search("Prevision") != -1 || title.search("Pto") != -1 ) {
      return true;
    } else {
      return false;
    }
  }
  generateColumns(columns: string[]) {

    let objectListToReturn = [];
    let i: number = 0;
    let j: number = 0;

    columns.forEach(element => {
      if (element.search('periodDataFuturo') != -1) {
        objectListToReturn.push(`amountFuturo${i}`)
        i += 1
      } else if (element.search('periodData') != -1) {
        objectListToReturn.push(`amount${j}`)
        j += 1
      } else {
        objectListToReturn.push(element)
      }

    });    
    return objectListToReturn;
  }

  extractDataFromResponse(data: any, tableId: string) {
    let listToReturn = [];
    let objectToReturn = {};
    
    //Por cada row (Objeto de la data de handsontable)
    let linea = 0; 
    data.forEach(row => {

      //Obtiene el nombre del atributo 
      Object.keys(row).forEach(atributo => {

        //Si el tipo no es un String PERIOD DATAS
        if (typeof (row[atributo]) != 'string') {

          //Si el tipo es PERIOD DATA
          if (atributo == "periodData") {
            // Se toma a la array de los meses y se guarda en el mismo objeto que todas las demas propiedades de la tabla 
            let i: number = 0;
            row[atributo].monthsAmounts.forEach(month => {
              // Se guarda con el siguiente formato "amount1, amount2 ...."
              objectToReturn[`amount${i}`] = month.amount;
              // Se obtienen los comentarios de esta celda, si tiene. 
              if(month.comments != null && month.comments != ''){              
                this.commentsList[tableId].push({row: linea, col: this.columnsToMap.indexOf(`amount${i}`), value: month.comments})
              }
              i += 1;
            });
          }

          //Si el tipo es PERIOD DATA ANIO SIGUIENTE 
          else if(atributo == "periodDataAnioSiguiente"){
            let i: number = 0;
            row[atributo].monthsAmounts.forEach(month => {
              // Se guarda con el siguiente formato "amount1, amount2 ...."
              objectToReturn[`amountFuturo${i}`] = month.amount;
              // Se obtienen los comentarios de esta celda, si tiene. 
              if(month.comments != null && month.comments != ''){                
                this.commentsList[tableId].push({row: linea, col: this.columnsToMap.indexOf(`amountFuturo${i}`), value: month.comments})
              }

              i += 1;
            });
         
          }

          //Si es prevRestanteAnioSiguiente o previsionesFuturo
          else if(atributo == "prevRestanteAnioSiguiente" || atributo == "previsionesFuturo"){
            objectToReturn[atributo] = row[atributo].value
            // Se obtienen los comentarios de esta celda, si tiene. 
            if(row[atributo].comments != null && row[atributo].comments != ""){
              this.commentsList[tableId].push({row: linea, col: this.columnsToMap.indexOf(atributo), value: row[atributo].comments})
            }
          }
          
        }
        //Si el tipo es un String (Campos que no corresponden a PeriodData)
        else {
          objectToReturn[atributo] = row[atributo];
        }
      })
      listToReturn.push(objectToReturn);
      objectToReturn = {}
      linea ++; 
    });

    
    return listToReturn;
  }
  generateMiddleTableColumnNames(){
    let columnName: string[] = [...this.columnNames];
    
    let columnNameToReturn: string[] = [];
    let limit =  columnName.length;
    for(let i=0; i < limit; i++){

      if(6 < i && i < limit-2){
        
        if(columnName[i].search('Real') != -1){
          columnNameToReturn.push(columnName[i].replace("Real", "Dif"));  
        }else{
          columnNameToReturn.push(`Dif ${columnName[i].replace("Prev", "")}`);
        }

      }else{
        columnNameToReturn.push(columnName[i]);
      }
    }
    return columnNameToReturn;
  }
  getHandsontable3(){


    let mesFotoActual = 9
    let mesLastFoto = 8

    let diferencia = mesFotoActual - mesLastFoto; 
    let handsontableA = this.hotRegisterer.getInstance("table1"); 
    let handsontableB =  this.hotRegisterer.getInstance("table2"); 
    let tableData1  = handsontableA.getData();
    let tableData2  = handsontableB.getData();
    this.columnNames3 = this.generateMiddleTableColumnNames();


    let result = []
    let rowIndex = 0; 
    for(let row of this.tableData){
      let newRow = {}
      let colIndex = 0;
      for(let key in row){
        // console.log(key) //Clove
        // console.log(row[key]) //Valor 

        /**
         * CONDICIONES PARA CADA CELDA
         * 
         * - (1) Si se trata de la primera columna de controles, el valor será el mismo texto 
         * 
         * - (2) Si es presupuesto (última fila) se deberá de obtener el valor directamente del td.textContent
         * Porque el value es un string que contiene la fórmula. Hay que exceptuar la fila 8 y 9 
         * porque estas serán evaluadas en otra condición. 
         * 
         * (**)
         * Para crear las 16 + numero de meses columnas, se hace una resta normal 
         *      Suponiengo que A es la tabla de arriba, C es la tabla de abajo, y se quiere calcular B
         *      B(x) = C(x) - A(x)
         * Para crear las columnas que tiene la tabla a pero no tiene la tabla c, solo se agrega un guión
         * Para crear las siguientes columnas, hay que ignorar las columnas que tiene de más la tabla de arriba, 
         * por lo que la operación, haciendo la misma suposición sería: 
         *      B(x) = C(x) - A(x + diferencia)
         * Para ambos casos se controla cuando el valor es #VALUE!
         */

         //(1) primera columna de controles
         if(key == "control") {
          newRow[key] = tableData1[rowIndex][colIndex]
        }
        // (2) Si es presupuesto, se extrae el valor de la tabla 
        else if(colIndex == this.columnsToMap.length - 1 && rowIndex != 7 && rowIndex != 8){     
          newRow[key] =  Number(tableData2[rowIndex][this.columnsToMap2.length - 1]) - Number(tableData1[rowIndex][colIndex]) 
        }
        else{
          if (colIndex < 16 + mesFotoActual) {
            if(tableData2[rowIndex][colIndex] == "#VALUE!" && tableData1[rowIndex][colIndex] == "#VALUE!"){
              newRow[key] = "0.00" 
            } else if(tableData2[rowIndex][colIndex] == "#VALUE!" && tableData1[rowIndex][colIndex] != "#VALUE!"){
              newRow[key] = Number("0.00") - Number(tableData1[rowIndex][colIndex])
            } else if(tableData2[rowIndex][colIndex] != "#VALUE!" && tableData1[rowIndex][colIndex] == "#VALUE!"){
              newRow[key] =  - Number(tableData2[rowIndex][colIndex]) - Number("0.00")
            } else {
              newRow[key] = Number(tableData2[rowIndex][colIndex]) - Number(tableData1[rowIndex][colIndex])
            }  
          }
          else if(colIndex >= 16 + mesFotoActual && colIndex < 16 + mesFotoActual + diferencia ) {
            newRow[key] = "0.00"
          }
          else {
            if(tableData2[rowIndex][colIndex - 1] == "#VALUE!" && tableData1[rowIndex][colIndex + diferencia - 1] == "#VALUE!"){
              newRow[key] = "0.00" 
            } else if(tableData2[rowIndex][colIndex - 1] == "#VALUE!" && tableData1[rowIndex][colIndex + diferencia - 1] != "#VALUE!"){
              newRow[key] = Number("0.00") - Number(tableData1[rowIndex][colIndex + diferencia - 1])
            } else if(tableData2[rowIndex][colIndex - 1] != "#VALUE!" && tableData1[rowIndex][colIndex + diferencia - 1] == "#VALUE!"){
              newRow[key] =  - Number(tableData2[rowIndex][colIndex - 1]) - Number("0.00")
            } else {
              newRow[key] = Number(tableData2[rowIndex][colIndex - 1]) - Number(tableData1[rowIndex][colIndex + diferencia - 1])
            }  
          } 
        }
        // console.log("Added ", key )
        colIndex ++;
      }
      result.push(newRow)
      // console.log("ROW ", newRow)
      rowIndex ++;
    }
    this.tableData3 = result; 
    console.log(this.tableData3)
  
  }

  getHandsontableIndicators1(){
    this.tablaData4 = []
    this.columnNames4 = [...this.columnNames];
    this.columnsToMap4 = [...this.columnsToMap];
    this.columnNames4[0] = "Indicador";

    let CPT_medio: Data = new Data();
    let AC: Data = new Data();
    let EV: Data = new Data();
    let PV: Data = new Data();
    let CPI: Data = new Data();
    let SPI: Data = new Data();

    CPT_medio['control'] = 'CPT_medio';
    AC['control'] = 'AC';
    EV['control'] = 'EV';
    PV['control'] = 'PV';
    CPI['control'] = 'CPI';
    SPI['control'] = 'SPI';


    let allDataTable = this.hotRegisterer.getInstance(this.tableId1).getData();

    for(let i = 0; i < allDataTable.length; i++){
      if(i != 2) continue;
      for(let j = 1; j < allDataTable[1].length; j++){
        //  se valida que sea la columna ""
        if(j == 6){
          CPT_medio[this.columnsToMap4[j]] = "0";
          //AC[this.columnsToMap4[j]] = "0"
        }else{
          if(Number(allDataTable[i][j]) == 0 || Number(allDataTable[i-1][j]) == 0){
            CPT_medio[this.columnsToMap4[j]] = ("0")  
          }else{
            CPT_medio[this.columnsToMap4[j]] = (Number(allDataTable[i][j]) / Number(allDataTable[i-1][j])).toString();
          }
          //AC[this.columnsToMap4[j]]= (Number(allDataTable[i][j]) + Number(allDataTable[i+1][j]) + Number(allDataTable[i+2][j])).toString();
        }
      }
    }
    this.tablaData4.push(CPT_medio, AC, EV, PV, CPI, SPI);
  }

  getHandsontableIndicators2(){
    this.tablaData5 = []
    this.columnNames5 = [...this.columnNames2];
    this.columnsToMap5 = [...this.columnsToMap2];
    this.columnNames5[0] = "Indicador";

    let CPT_medio: Data = new Data();
    let AC: Data = new Data();
    let EV: Data = new Data();
    let PV: Data = new Data();
    let CPI: Data = new Data();
    let SPI: Data = new Data();

    CPT_medio['control'] = 'CPT_medio';
    AC['control'] = 'AC';
    EV['control'] = 'EV';
    PV['control'] = 'PV';
    CPI['control'] = 'CPI';
    SPI['control'] = 'SPI';


    let allDataTable = this.hotRegisterer.getInstance(this.tableId2).getData();

    for(let i = 0; i < allDataTable.length; i++){
      if(i != 2) continue;
      for(let j = 1; j < allDataTable[1].length; j++){
        //  se valida que sea la columna ""
        if(j == 6){
          CPT_medio[this.columnsToMap5[j]] = "0";
          //AC[this.columnsToMap5[j]] = "0"
        }else{
          if(Number(allDataTable[i][j]) == 0 || Number(allDataTable[i-1][j]) == 0){
            CPT_medio[this.columnsToMap5[j]] = ("0")  
          }else{
            CPT_medio[this.columnsToMap5[j]] = (Number(allDataTable[i][j]) / Number(allDataTable[i-1][j])).toString();
          }
          //AC[this.columnsToMap5[j]]= (Number(allDataTable[i][j]) + Number(allDataTable[i+1][j]) + Number(allDataTable[i+2][j])).toString();
        }
      }
    }

    this.tablaData5.push(CPT_medio, AC, EV, PV, CPI, SPI);
    
  }
  colHeadersColor(col, TH){
    if (col == 0 || col == 1 || col == 2 || col == 6) {
      TH.style.backgroundColor = "#44546A";
      TH.style.color = "#ffff";
    }
    else if (col == 3) {
      TH.style.backgroundColor = "#92D050";
    }
    else if (TH.textContent.search("Real") != -1) {
      TH.style.backgroundColor = "#00B050";
    }
    else if (TH.textContent.search("Prevision") != -1 || col == 5 || col > this.columnNames.length - 3) {
      TH.style.backgroundColor = "#FFFF00";
    }
    else if (TH.textContent.search("Prev ") != -1 && col < 19) {
      TH.style.backgroundColor = "#FFF2CC";
    }
    else if(col >= 19){
      TH.style.backgroundColor = "#FFDFCC";
    }
  }

  afterChangeTable1(changes) {
    try {

      changes.forEach((changes, src) => {

        let row = changes[0]
        let col = changes[1]
        let newValue = changes[3]

        /**
         * Asigna el valor real de la celda en formato número 
         */
        if (newValue.includes(",")) {
          let indexCol = this.columnsToMap.indexOf(col.toString());
          let value = Number(newValue.toString().replace(".", "").replace(",", ".")).toFixed(2)
          this.hotRegisterer.getInstance(this.tableId1).setDataAtCell(row, indexCol, value);
        }
        if (!newValue) {
          let indexCol = this.columnsToMap.indexOf(col.toString());
          this.hotRegisterer.getInstance(this.tableId1).setDataAtCell(row, indexCol, "0.00");
        }

        let indexCol = this.columnsToMap.indexOf(col.toString());
        this.hotRegisterer.getInstance(this.tableId1).setCellMeta(row, indexCol, 'className', 'isDirty');
        this.hotRegisterer.getInstance(this.tableId1).render(); 

        // this.getHandsontable3(); 
        // this.getHandsontableIndicators1();
      });
    } catch (error) {
      console.error();
    }
  }

  hotSettings1: Handsontable.GridSettings = {
    formulas: {
      engine: HyperFormula
    },

    rowHeights: 30,
    // : ['commentsAddEdit', 'commentsRemove', 'commentsReadOnly'],
    contextMenu: {items:{
      "Añadir Comentario":{
        name: 'Añadir Comentario',
        callback:(key, options) =>{
          let col = options[0].end.col;
          let row = options[0].end.row;
          this.hotRegisterer.getInstance(this.tableId1).getPlugin('comments').showAtCell(row, col);   
        },
        hidden: ()=>{
          // Se obtiene la fila y la columna que ha sido clickeada. (indice de estas)
          let row = this.hotRegisterer.getInstance(this.tableId1).getSelectedLast()[0];
          let col = this.hotRegisterer.getInstance(this.tableId1).getSelectedLast()[1];
          let listOfNumber: number[] = [];

          for(let i=0; i<this.limitOfHeaders; i++){
            listOfNumber.push(i);
          }
          let colMesFoto = this.columnNames.findIndex(mes => mes.includes("202109"));
          if( col === colMesFoto && !this.rOnly && (row === 5 )){
            return false;
          }

          if(this.roles.includes('ROLE_ADMIN') || 
          this.roles.includes('ROLE_CONTROLLER_PYC') || this.roles.includes('ROLE_DIRECTOR_PYC')){
            if( col === colMesFoto && !this.rOnly && (row === 0 )){
              return false;
            }
          }
          if(listOfNumber.includes(col)||[0,8,7,5].includes(row) || this.rOnly){
            return true;
          }
          else{
            return false
          }
        }
      }
    }},
    manualColumnResize: true,
    comments: true,
    licenseKey: 'non-commercial-and-evaluation',
    fixedColumnsLeft: 7,      
    //Para asignar colores a los headers 
    afterGetColHeader: (col, TH) => {
      this.colHeadersColor(col, TH)
    },
    //AFTERCHANGE Se activa cuando se realiza algún cambio a cualquier celda
    afterChange: (changes) => {
      this.afterChangeTable1(changes); 

    }, 
    cells(row, column) {
      
      if (column != 0 && row != 8) {
        return {
          renderer(instance, td, row, col, prop, value, cellProperties) {
            Handsontable.renderers.TextRenderer.apply(this, arguments)
            if(td.className == "isDirty"){
              td.style.background = "#E2D6F3"
            }
            try {
              /**
               * Se convierte al formato de número para que las fórmulas 
               * funcionen
               */
              td.className = "htRight"
              value = Number(value.toString().replace(",", ".")).toFixed(2)
              td.textContent = value.toString().replace(".", ",").replace(/\B(?=(\d{3})+(?!\d))/g, ".");
              if (row == 0) {
                td.style.backgroundColor = "#E2F6DA";
              }
              if (row == 7) {
                cellProperties.readOnly = true
                td.style.backgroundColor = "#FFE699"
                if (col == instance.countSourceCols() - 1 && value > 0) {
                  td.style.color = '#C74687'
                }
              }
              if (col == instance.countSourceCols() - 1 && row != 7) {
                if (value < 0) {
                  td.style.color = 'red'
                }
              }
            } catch (error) {
              console.log(error)
            }
          }
        }
      }
      else if (row == 8) {
        return {
          renderer(instance, td, row, col, prop, value, cellProperties) {
            Handsontable.renderers.TextRenderer.apply(this, arguments)
            if (col != 0) {
              td.className = "htRight"
            }

            if (col == 0) {
              td.style.backgroundColor = "#E2EFDA";
            } else {
              td.style.backgroundColor = "#FFE699";
            }

            if (col != 0) {
              if (td.textContent == "#VALUE!") {
                td.innerHTML = "0%";
                cellProperties.readOnly = true;
              }
              else {
                td.textContent = Number(td.textContent).toFixed(2) + "%";
              }
            }
            if (col == instance.countSourceCols() - 1 && value > 0) {
              td.style.color = '#C74687'
            }
            cellProperties.readOnly = true;
          }
        }
      }
      else {
        return {
          renderer(instance, td, row, col, prop, value, cellProperties) {
            Handsontable.renderers.TextRenderer.apply(this, arguments)

            if (col == 0) {
              td.style.backgroundColor = "#E2EFDA";
            } else {
              td.style.backgroundColor = "#FFE699";
              cellProperties.readOnly = true;
            }
          }
        }
      }
    }, 
    afterInit : () => {
      // this.setComents(this.tableId1);
      // this.interactiveService.sett1(true); 
      // this.interactiveService.setT1Aux(true); 
      // this.interactiveService.setT1Aux2(true); 

      for(let i = 0; i < this.columnsToMap.length; i ++){
        this.inicialWidths.push(this.hotRegisterer.getInstance(this.tableId1).getColWidth(i))
      }   
    }
  }

  hotSettings2: Handsontable.GridSettings = {
    formulas: {
      engine: HyperFormula
    },
    rowHeights: 30,
    comments: true,
    manualColumnResize: this.inicialWidths,
    contextMenu: ['commentsReadOnly'],
    licenseKey: 'non-commercial-and-evaluation',
    fixedColumnsLeft: 7,
    readOnly: true,
    //Para asignar colores a los headers 
    afterGetColHeader: (col, TH) => {
      this.colHeadersColor(col, TH)
    },
    //AFTERCHANGE Se activa cuando se realiza algún cambio a cualquier celda
    afterChange: (changes) => {
      this.afterChangeTable1(changes); 
    }, 
    cells(row, column) {
      if (column != 0 && row != 8) {
        return {
          renderer(instance, td, row, col, prop, value, cellProperties) {
            Handsontable.renderers.TextRenderer.apply(this, arguments)
            try {
              /**
               * Se convierte al formato de número para que las fórmulas 
               * funcionen
               */
              
              td.className = "htRight"
              value = Number(value.toString().replace(",", ".")).toFixed(2)
              td.textContent = value.toString().replace(".", ",").replace(/\B(?=(\d{3})+(?!\d))/g, ".");
              if (row == 0) {
                td.style.backgroundColor = "#E2F6DA";
              }
              if (row == 7) {
                cellProperties.readOnly = true
                td.style.backgroundColor = "#FFE699"
                if (col == instance.countSourceCols() - 1 && value > 0) {
                  td.style.color = '#C74687'
                }
              }
              if (col == instance.countSourceCols() - 1 && row != 7) {
                if (value < 0) {
                  td.style.color = 'red'
                }
              }
            } catch (error) {
              console.log(error)
            }
          }
        }
      }
      else if (row == 8) {
        return {
          renderer(instance, td, row, col, prop, value, cellProperties) {
            Handsontable.renderers.TextRenderer.apply(this, arguments)
            if (col != 0) {
              td.className = "htRight"
            }

            if (col == 0) {
              td.style.backgroundColor = "#E2EFDA";
            } else {
              td.style.backgroundColor = "#FFE699";
            }

            if (col != 0) {
              if (td.textContent == "#VALUE!") {
                td.innerHTML = "0%";
                cellProperties.readOnly = true;
              }
              else {
                td.textContent = Number(td.textContent).toFixed(2) + "%";
              }
            }
            if (col == instance.countSourceCols() - 1 && value > 0) {
              td.style.color = '#C74687'
            }
            cellProperties.readOnly = true;
          }
        }
      }
      else {
        return {
          renderer(instance, td, row, col, prop, value, cellProperties) {
            Handsontable.renderers.TextRenderer.apply(this, arguments)

            if (col == 0) {
              td.style.backgroundColor = "#E2EFDA";
            } else {
              td.style.backgroundColor = "#FFE699";
              cellProperties.readOnly = true;
            }
          }
        }
      }
    }, 
    afterInit : () => {
      // this.setComents(this.tableId2);
      // this.interactiveService.sett2(true)
      // this.interactiveService.setT2Aux(true)
    }     
  }
    hotSettings3: Handsontable.GridSettings = {
      readOnly: true,
      formulas: {
        engine: HyperFormula
      },
      rowHeights: 30,
      manualColumnResize: this.inicialWidths,
      fixedColumnsLeft: 7,
      licenseKey: 'non-commercial-and-evaluation',
      cells(row, column) {
        if (column != 0 && row != 8) {
          return {
            renderer(instance, td, row, col, prop, value, cellProperties) {
              Handsontable.renderers.TextRenderer.apply(this, arguments)
              try {
  
                td.className = "htRight"
                value = Number(value.toString().replace(",", ".")).toFixed(2)
                td.textContent = value.toString().replace(".", ",").replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  
                /**
                 * Lineas 1, 6, 7, 8 y 9 son rojos si es positivo. Porque  son cobros/ingresos
                 */
                if(row == 0 || row == 5 || row == 6 || row == 7){
                  if(value > 0){
                    td.style.color = 'red'
                    td.style.backgroundColor = '#E5E7E9 '
                  }
                }
                /**
                 * Otras lineas serán rojas si el valor es menor a 0 
                 */
                else {
                  if(value < 0){
                    td.style.color = 'red'
                  }
                }
              } catch (error) {
              }
            }
          }
        }
        else if (row == 8) {
          return {
            renderer(instance, td, row, col, prop, value, cellProperties) {
              Handsontable.renderers.TextRenderer.apply(this, arguments)
              if(value > 0){
                td.style.color = 'red'
                td.style.backgroundColor = '#E5E7E9 '
              }
              if (col != 0) {
                td.className = "htRight"
              }
              if(col == 0){
                td.style.backgroundColor = "#E2EFDA";
              }
              if (col != 0) {
                if (td.textContent == "#VALUE!") {
                  td.innerHTML = "0%";
                  cellProperties.readOnly = true;
                }
                else {
                  td.textContent = Number(td.textContent).toFixed(2) + "%";
                }
              }
            }
          }
        }
        else {
          return {
            renderer(instance, td, row, col, prop, value, cellProperties) {
              Handsontable.renderers.TextRenderer.apply(this, arguments)
  
              if (col == 0) {
                td.style.backgroundColor = "#E2EFDA";
              } 
            }
          }
        }
      },
      afterInit : () => {
        // this.interactiveService.sett3(true)
      } 
    }

    /*********************
   * HOTSETTINGS TABLA 4
   *********************/
  hotSettingsIndicators1: Handsontable.GridSettings = {
    formulas: {
      engine: HyperFormula
    },
    rowHeights: 30,
    licenseKey: 'non-commercial-and-evaluation',
    fixedColumnsLeft: 7,
    readOnly: true,
    // manualColumnResize: [124], //Se le asignan 122 px a la primera col (124 = 122px)
    manualColumnResize: this.inicialWidths,
    afterGetColHeader: (col, TH) => {
      this.colHeadersColor(col, TH)
    },
    //AFTERCHANGE.Se activa cuando se realiza algún cambio a cualquier celda
    cells(row, column) {
      if(column == 0){
        return {
          renderer(instance, td, row, col, prop, value, cellProperties){
            Handsontable.renderers.TextRenderer.apply(this, arguments)
            td.style.background = "#E2EFDA";
          }
        }
      }
      if (column != 0) {
        return {
          renderer(instance, td, row, col, prop, value, cellProperties) {
            Handsontable.renderers.TextRenderer.apply(this, arguments)
            try {
              /**
               * Se convierte al formato de número para que las fórmulas 
               * funcionen
               */
              td.className = "htRight"
              value = Number(value.toString().replace(",", ".")).toFixed(2)
              td.textContent = value.toString().replace(".", ",").replace(/\B(?=(\d{3})+(?!\d))/g, ".");
            
              if (row == 7) {
                cellProperties.readOnly = true
                td.style.backgroundColor = "#FFE699"
                if (col == instance.countSourceCols() - 1 && value > 0) {
                  td.style.color = '#C74687'
                }
              }
              if (col == instance.countSourceCols() - 1) {
                if (value < 0) {
                  td.style.color = 'red'
                }
              }
            } catch (error) {
              // console.log(error)
            }
          }
        }
      }
    },
    afterInit : () => {
      // this.interactiveService.sett4(true)
    } 
  }

  /*********************
   * HOTSETTINGS TABLA 5
   *********************/
   hotSettingsIndicators2: Handsontable.GridSettings = {
    formulas: {
      engine: HyperFormula
    },
    rowHeights: 30,
    licenseKey: 'non-commercial-and-evaluation',
    fixedColumnsLeft: 7,
    readOnly: true,
    //manualColumnResize: [124], //Se le asignan 122 px a la primera col (124 = 122px)
    manualColumnResize: this.inicialWidths,
    afterGetColHeader: (col, TH) => {
      this.colHeadersColor(col, TH)
    },
    //AFTERCHANGE.Se activa cuando se realiza algún cambio a cualquier celda
    cells(row, column) {
      if(column == 0){
        return {
          renderer(instance, td, row, col, prop, value, cellProperties){
            Handsontable.renderers.TextRenderer.apply(this, arguments)
            td.style.background = "#E2EFDA";
          }
        }
      }
      if (column != 0) {
        return {
          renderer(instance, td, row, col, prop, value, cellProperties) {
            Handsontable.renderers.TextRenderer.apply(this, arguments)
            try {
              /**
               * Se convierte al formato de número para que las fórmulas 
               * funcionen
               */
              td.className = "htRight"
              value = Number(value.toString().replace(",", ".")).toFixed(2)
              td.textContent = value.toString().replace(".", ",").replace(/\B(?=(\d{3})+(?!\d))/g, ".");
            
              if (row == 7) {
                cellProperties.readOnly = true
                td.style.backgroundColor = "#FFE699"
                if (col == instance.countSourceCols() - 1 && value > 0) {
                  td.style.color = '#C74687'
                }
              }
              if (col == instance.countSourceCols() - 1) {
                if (value < 0) {
                  td.style.color = 'red'
                }
              }
            } catch (error) {
              // console.log(error)
            }
          }
        }
      }
    },
    afterInit : () => {
      // this.interactiveService.sett5(true); 
    } 
  }

  colHeadersColorDetail(col, TH){

    if (col > 1){
      const button = TH.querySelector('.changeType');
      
      if (!button) {
        return;
      }
      
      button.parentElement.removeChild(button);
    }
    if (col == 0 || col == 1 || col == 2 || col == 3 || col== 4 || col == 8) {
      TH.style.backgroundColor = "#44546A";
      TH.style.color = "#ffff";
    }
    else if (col == 5) {
      TH.style.backgroundColor = "#92D050";
    }
    else if (TH.textContent.search("Real") != -1) {
      TH.style.backgroundColor = "#00B050";
    }
    else if (col > 40 - 3 || col == 7 || col == 6) {
      TH.style.backgroundColor = "#FFFF00";
    }
    else if (TH.textContent.search("Prev ") != -1 && col < 19) {
      TH.style.backgroundColor = "#FFF2CC";
    }
    else if(col >= 19){
      TH.style.backgroundColor = "#FFDFCC";
    }
  }

  hotSettingsDetail: Handsontable.GridSettings = {
    fixedColumnsLeft: 3,
    readOnly: false,
    dropdownMenu: ['filter_by_value', 'filter_action_bar'],
    columnSorting: true,
    filters: true,
    colHeaders:true,
    formulas: {
      engine: HyperFormula
    },
    licenseKey: 'non-commercial-and-evaluation',
    manualColumnResize: true,
    afterGetColHeader: (col, TH)=>{
      this.colHeadersColorDetail(col, TH);
    },
    // mergeCells: [{row:0, col:1, rowspan: 9, colspan:1}],  
     cells(row, col) {
      
      if(col == 0 || col == 1 || col == 2){
        return {
          renderer(instance, td, row, col, prop, value, cellProperties) {
            Handsontable.renderers.TextRenderer.apply(this, arguments)
            td.style.backgroundColor = "#E2F6DA";

            /**
             * Centrar al agrupar celdas
             */
            // if(col == 0 || col == 1){
            //   td.style.textAlign = 'center'; 
            //   td.className = 'htLeft htMiddle';
            // }
          }
        }
      }
      else if((row != 8 || row%9 != 8) && row%9 != 8){
        return{
          renderer(instance, td, row, col, prop, value, cellProperties) {
            Handsontable.renderers.TextRenderer.apply(this, arguments)
            try {
              /**
               * Se convierte al formato de número para que las fórmulas 
               * funcionen
               */
              td.className = "htRight"
              value = Number(value.toString().replace(",", ".")).toFixed(2)
              td.textContent = value.toString().replace(".", ",").replace(/\B(?=(\d{3})+(?!\d))/g, ".");
              if (row == 0 || row%9 == 0) {
                td.style.backgroundColor = "#E2F6DA";
              }
              if (row == 7 || row%9 == 7 ) {
                td.style.backgroundColor = "#FFE699"
              }
            } catch (error) {
              console.log(error)
            }
          }
        }
      } else if (row == 8 || row%9 == 8){
        return {
          renderer(instance, td, row, col, prop, value, cellProperties) {
            Handsontable.renderers.TextRenderer.apply(this, arguments)
            td.style.backgroundColor = "#FFE699"
            td.className = "htRight"
            if (td.textContent == "#VALUE!") {
                td.innerHTML = "0%";
            }
            else {
              td.textContent = Number(td.textContent).toFixed(2) + "%";
            }
          }
        }
      }
    } 
  }
}

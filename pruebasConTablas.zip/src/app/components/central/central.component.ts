import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-central',
  templateUrl: './central.component.html',
  styleUrls: ['./central.component.css']
})
export class CentralComponent implements OnInit {

  constructor() { 
    console.log("Hello");
    
  }

  ngOnInit(): void {
  }

  title = 'handsontables';

  loading: boolean = false; 
  id: number ; 
  /**
   * PROJECTS
   */

   generateTable(id: number){
     this.id = id; 
   }

}
